# 🚀 WorkOS — Full-Stack SaaS Platform
### Timer + Video Conferencing + CRM/Analytics

> **Stack выбран под максимальную производительность в 2026:**
> Go (backend) · Next.js 14 (frontend) · PostgreSQL + Redis + ClickHouse · LiveKit (WebRTC) · Docker + Kubernetes · GitHub Actions

---

## Что такое WorkOS SaaS

Единая платформа для команд и бизнеса, объединяющая:

| Модуль | Описание |
|--------|----------|
| ⏱ **Timer / Time Tracking** | Трекинг времени по проектам, задачам, клиентам. Отчёты, экспорт, интеграции |
| 🎥 **Video Conferencing** | Встроенные видеозвонки и конференции (WebRTC через LiveKit) |
| 📊 **CRM + Analytics** | Контакты, сделки, воронка продаж, дашборды, аналитика |

---

## Архитектура (кратко)

```
[Клиент: Next.js 14]
        │
[API Gateway: Go + Kong]
        │
┌───────┼────────────────────────────────┐
│       │                                │
[auth]  [timer]  [video]  [crm]  [billing] [analytics] [admin] [notify]
│       │        │        │      │          │            │       │
└───────┴────────┴────────┴──────┴──────────┴────────────┴───────┘
                          │
              [PostgreSQL · Redis · ClickHouse]
```

---

## Документы этого пакета

| Файл | Содержимое |
|------|-----------|
| `01-architecture.md` | Полная архитектура микросервисов |
| `02-backend-go.md` | Go-сервисы: структура, код, паттерны |
| `03-database.md` | Схемы PostgreSQL, Redis, ClickHouse |
| `04-frontend.md` | Next.js 14, TypeScript, компоненты |
| `05-api-spec.md` | REST API + OpenAPI 3.0 (Swagger) |
| `06-billing-stripe.md` | Stripe: подписки, webhooks, мультитенант |
| `07-video-livekit.md` | LiveKit WebRTC: комнаты, токены, запись |
| `08-admin-panel.md` | Админ-панель: роли, тенанты, метрики |
| `09-devops-cicd.md` | Docker, Kubernetes, GitHub Actions |
| `10-roadmap.md` | Дорожная карта: MVP → V1 → V2 |

---

## Быстрый старт (локально)

```bash
# 1. Клонируем репозиторий
git clone https://github.com/your-org/workos-saas.git
cd workos-saas

# 2. Поднимаем инфраструктуру
docker-compose up -d postgres redis clickhouse livekit

# 3. Запускаем все Go-сервисы
make run-all

# 4. Запускаем фронтенд
cd frontend && npm install && npm run dev

# 5. Открываем
# App:    http://localhost:3000
# Swagger:http://localhost:8080/swagger
# Admin:  http://localhost:3000/admin
```

---

## Мультитенантность

Каждая организация (тенант) изолирована:
- Отдельная схема в PostgreSQL (`tenant_{id}`)
- Tenant ID в JWT-токенах и заголовке `X-Tenant-ID`
- Row-level security на уровне БД
- Отдельные Stripe-подписки и лимиты

---

## Команда агентов (Claude Code workflow)

```
Ты (архитектор) → даёшь задачи
Claude Code (агент) → пишет код, тесты, PR
CI/CD → прогоняет тесты, линтеры
Ты → мержишь PR, контролируешь прод
```
