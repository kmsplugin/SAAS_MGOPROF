# 01 — Архитектура микросервисов

## Почему Go (и не что-то другое)

| Критерий | Go | .NET | Node.js |
|----------|-----|------|---------|
| Конкурентность (видео) | ✅ Goroutines | ✅ async/await | ⚠️ Event loop |
| Производительность | ✅ Нативная | ✅ Хорошая | ⚠️ Средняя |
| WebRTC / LiveKit SDK | ✅ Нативный | ⚠️ Обёртка | ⚠️ Обёртка |
| Микросервисы | ✅ Идеально | ✅ Хорошо | ⚠️ Сложнее |
| Бинарные сборки | ✅ 1 файл | ⚠️ Runtime | ⚠️ Runtime |
| Компания LiveKit | ✅ Go-first | — | — |

**Вывод:** Go — единственный правильный выбор для этой комбинации.

---

## Полная схема архитектуры

```
┌─────────────────────────────────────────────────────────┐
│                    КЛИЕНТ (Browser/App)                  │
│           Next.js 14 · TypeScript · Tailwind             │
└─────────────────────────┬───────────────────────────────┘
                          │ HTTPS / WSS
┌─────────────────────────▼───────────────────────────────┐
│                    API GATEWAY                           │
│              Go + Kong + Rate Limiting                   │
│         JWT validation · Tenant resolution               │
└──┬────┬────┬────┬────┬────┬────┬────┬───────────────────┘
   │    │    │    │    │    │    │    │
   ▼    ▼    ▼    ▼    ▼    ▼    ▼    ▼
[auth][timer][video][crm][billing][analytics][admin][notify]
   │    │    │    │    │    │    │    │
   └────┴────┴────┴────┴────┴────┴────┘
                    │
        ┌───────────┼───────────┐
        ▼           ▼           ▼
   [PostgreSQL]  [Redis]  [ClickHouse]
   Multi-schema  Cache    Analytics
   per tenant    Sessions  Events
```

---

## Сервисы и их ответственность

### 1. `auth-service` (порт 8001)
- Регистрация / логин / OAuth2 (Google, GitHub)
- JWT access + refresh tokens
- Мультитенантная авторизация
- RBAC: Owner, Admin, Manager, Member, Viewer

```go
// Структура JWT payload
type Claims struct {
    UserID   string `json:"sub"`
    TenantID string `json:"tenant_id"`
    Role     string `json:"role"`
    Email    string `json:"email"`
    jwt.RegisteredClaims
}
```

### 2. `timer-service` (порт 8002)
- Создание проектов и задач
- Старт/стоп таймера (real-time через WebSocket)
- Трекинг времени с точностью до секунды
- Отчёты: по пользователю, проекту, дате
- Экспорт: CSV, PDF, JSON

### 3. `video-service` (порт 8003)
- Управление комнатами через LiveKit Server API
- Генерация токенов для входа в комнату
- Запись сессий в S3/MinIO
- Webhooks событий комнаты
- Статистика участников и длительности

### 4. `crm-service` (порт 8004)
- Контакты (Contacts): физические и юридические лица
- Сделки (Deals): воронка, стадии, вероятность
- Активности (Activities): звонки, встречи, задачи
- Связь с timer (сколько времени потрачено на клиента)

### 5. `billing-service` (порт 8005)
- Stripe Customers + Subscriptions
- Планы: Free / Starter / Pro / Enterprise
- Stripe Webhooks (оплата, отмена, просрочка)
- Лимиты по тенанту: пользователи, хранилище, минуты видео

### 6. `analytics-service` (порт 8006)
- Агрегация событий из всех сервисов в ClickHouse
- Дашборды: время, продуктивность, CRM-воронка
- Пользовательские отчёты с фильтрами
- Export в CSV/PDF

### 7. `admin-service` (порт 8007)
- SuperAdmin панель (все тенанты)
- Tenant Admin панель (свой тенант)
- Управление пользователями, ролями, лимитами
- System health, logs, metrics

### 8. `notification-service` (порт 8008)
- Email (Resend / SendGrid)
- In-app notifications (WebSocket)
- Webhook исходящие (интеграции)

---

## Межсервисное взаимодействие

```
Синхронно:  REST (между сервисами через Service Discovery)
Асинхронно: Redis Pub/Sub (события: timer.started, deal.created...)
Реальное время: WebSocket (timer live update, notifications)
```

---

## Технологический стек (полный)

| Слой | Технология | Версия |
|------|-----------|--------|
| Backend language | Go | 1.23+ |
| Web framework | Gin | v1.9+ |
| ORM | GORM | v2 |
| Migrations | golang-migrate | v4 |
| Auth | golang-jwt | v5 |
| Config | Viper | v2 |
| Logger | Zap | v1.27 |
| Metrics | Prometheus + Grafana | latest |
| Tracing | OpenTelemetry | v1 |
| Video | LiveKit Go SDK | v1.5+ |
| Payments | Stripe Go SDK | v78+ |
| API Docs | Swaggo/swag | v1.16+ |
| Frontend | Next.js | 14+ |
| UI Library | shadcn/ui + Tailwind | latest |
| DB (main) | PostgreSQL | 16 |
| DB (cache) | Redis | 7.2 |
| DB (analytics) | ClickHouse | 24 |
| Container | Docker | 26+ |
| Orchestration | Kubernetes | 1.30+ |
| CI/CD | GitHub Actions | — |
| Reverse proxy | Nginx / Traefik | — |
| Object storage | MinIO / S3 | — |

---

## Структура монорепозитория

```
workos-saas/
├── services/
│   ├── auth/
│   ├── timer/
│   ├── video/
│   ├── crm/
│   ├── billing/
│   ├── analytics/
│   ├── admin/
│   └── notification/
├── gateway/
├── frontend/
├── shared/
│   ├── middleware/
│   ├── models/
│   └── utils/
├── infrastructure/
│   ├── docker/
│   ├── k8s/
│   └── terraform/
├── migrations/
├── docs/
├── scripts/
├── Makefile
└── docker-compose.yml
```
