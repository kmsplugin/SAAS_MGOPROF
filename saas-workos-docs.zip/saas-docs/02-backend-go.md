# 02 — Backend Go: Структура, Код, Паттерны

## Структура каждого сервиса (единый шаблон)

```
services/timer/
├── cmd/
│   └── main.go              # Точка входа
├── internal/
│   ├── config/
│   │   └── config.go        # Конфиг через Viper
│   ├── handler/
│   │   └── timer_handler.go # HTTP handlers (Gin)
│   ├── service/
│   │   └── timer_service.go # Бизнес-логика
│   ├── repository/
│   │   └── timer_repo.go    # Работа с БД (GORM)
│   └── model/
│       └── timer.go         # GORM модели
├── docs/                    # Swagger авто-генерация
├── Dockerfile
└── go.mod
```

---

## main.go (шаблон для всех сервисов)

```go
package main

import (
    "context"
    "log"
    "net/http"
    "os"
    "os/signal"
    "syscall"
    "time"

    "github.com/gin-gonic/gin"
    "go.uber.org/zap"

    "workos/services/timer/internal/config"
    "workos/services/timer/internal/handler"
    "workos/services/timer/internal/repository"
    "workos/services/timer/internal/service"
    "workos/shared/middleware"
    "workos/shared/database"
)

// @title           WorkOS Timer API
// @version         1.0
// @description     Time tracking service
// @securityDefinitions.apikey BearerAuth
// @in header
// @name Authorization
func main() {
    // Logger
    logger, _ := zap.NewProduction()
    defer logger.Sync()

    // Config
    cfg := config.Load()

    // Database
    db := database.Connect(cfg.DatabaseURL)
    database.Migrate(db)

    // Redis
    rdb := database.ConnectRedis(cfg.RedisURL)

    // Dependencies
    repo := repository.NewTimerRepository(db)
    svc  := service.NewTimerService(repo, rdb, logger)
    h    := handler.NewTimerHandler(svc, logger)

    // Router
    r := gin.New()
    r.Use(gin.Recovery())
    r.Use(middleware.Logger(logger))
    r.Use(middleware.CORS())
    r.Use(middleware.Tenant()) // Извлекаем tenant_id из JWT

    // Routes
    v1 := r.Group("/api/v1")
    v1.Use(middleware.Auth(cfg.JWTSecret))
    {
        h.RegisterRoutes(v1)
    }

    // Health check
    r.GET("/health", func(c *gin.Context) {
        c.JSON(http.StatusOK, gin.H{"status": "ok"})
    })

    // Swagger
    // r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

    // Graceful shutdown
    srv := &http.Server{
        Addr:    ":" + cfg.Port,
        Handler: r,
    }

    go func() {
        if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
            log.Fatalf("listen: %s\n", err)
        }
    }()

    quit := make(chan os.Signal, 1)
    signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
    <-quit

    ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
    defer cancel()
    srv.Shutdown(ctx)
}
```

---

## Модели (GORM + мультитенант)

```go
// shared/models/base.go
package models

import (
    "time"
    "github.com/google/uuid"
    "gorm.io/gorm"
)

type Base struct {
    ID        uuid.UUID      `gorm:"type:uuid;primary_key;default:gen_random_uuid()" json:"id"`
    CreatedAt time.Time      `json:"created_at"`
    UpdatedAt time.Time      `json:"updated_at"`
    DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

// Мультитенантная база для всех моделей
type TenantBase struct {
    Base
    TenantID uuid.UUID `gorm:"type:uuid;not null;index" json:"tenant_id"`
}

// services/timer/internal/model/timer.go
type Project struct {
    TenantBase
    Name        string     `gorm:"not null" json:"name"`
    Description string     `json:"description"`
    Color       string     `gorm:"default:'#6366f1'" json:"color"`
    ClientID    *uuid.UUID `gorm:"type:uuid" json:"client_id,omitempty"`
    IsArchived  bool       `gorm:"default:false" json:"is_archived"`
    Entries     []TimeEntry `gorm:"foreignKey:ProjectID" json:"entries,omitempty"`
}

type TimeEntry struct {
    TenantBase
    ProjectID   uuid.UUID  `gorm:"type:uuid;not null" json:"project_id"`
    UserID      uuid.UUID  `gorm:"type:uuid;not null" json:"user_id"`
    Description string     `json:"description"`
    StartedAt   time.Time  `gorm:"not null" json:"started_at"`
    StoppedAt   *time.Time `json:"stopped_at,omitempty"`
    Duration    *int64     `json:"duration,omitempty"` // секунды
    IsBillable  bool       `gorm:"default:true" json:"is_billable"`
    Tags        []Tag      `gorm:"many2many:time_entry_tags" json:"tags,omitempty"`
}

type Tag struct {
    TenantBase
    Name  string `gorm:"not null" json:"name"`
    Color string `json:"color"`
}
```

---

## Middleware (мультитенантность + JWT)

```go
// shared/middleware/tenant.go
package middleware

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "github.com/golang-jwt/jwt/v5"
)

type Claims struct {
    UserID   string `json:"sub"`
    TenantID string `json:"tenant_id"`
    Role     string `json:"role"`
    Email    string `json:"email"`
    jwt.RegisteredClaims
}

func Auth(secret string) gin.HandlerFunc {
    return func(c *gin.Context) {
        tokenStr := extractBearerToken(c)
        if tokenStr == "" {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "missing token"})
            return
        }

        claims := &Claims{}
        token, err := jwt.ParseWithClaims(tokenStr, claims, func(t *jwt.Token) (interface{}, error) {
            return []byte(secret), nil
        })
        if err != nil || !token.Valid {
            c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid token"})
            return
        }

        // Вшиваем tenant_id и user_id в контекст запроса
        c.Set("tenant_id", claims.TenantID)
        c.Set("user_id",   claims.UserID)
        c.Set("user_role", claims.Role)
        c.Next()
    }
}

// В каждом репозитории автоматически фильтруем по tenant_id
func (r *TimerRepository) scopedDB(c *gin.Context) *gorm.DB {
    tenantID := c.GetString("tenant_id")
    return r.db.Where("tenant_id = ?", tenantID)
}
```

---

## Timer Service: бизнес-логика

```go
// services/timer/internal/service/timer_service.go
package service

import (
    "context"
    "errors"
    "time"
    "github.com/google/uuid"
    "go.uber.org/zap"

    "workos/services/timer/internal/model"
    "workos/services/timer/internal/repository"
)

type TimerService struct {
    repo   *repository.TimerRepository
    redis  *redis.Client
    logger *zap.Logger
}

// StartTimer — стартует новую запись времени
// Если у пользователя уже есть активный таймер — останавливает его
func (s *TimerService) StartTimer(ctx context.Context, tenantID, userID, projectID uuid.UUID, desc string) (*model.TimeEntry, error) {
    // Остановить активный таймер если есть
    active, _ := s.repo.FindActive(ctx, tenantID, userID)
    if active != nil {
        s.StopTimer(ctx, tenantID, userID, active.ID)
    }

    entry := &model.TimeEntry{
        TenantBase:  models.TenantBase{TenantID: tenantID},
        ProjectID:   projectID,
        UserID:      userID,
        Description: desc,
        StartedAt:   time.Now().UTC(),
    }

    if err := s.repo.Create(ctx, entry); err != nil {
        return nil, err
    }

    // Публикуем событие для real-time обновления UI
    s.publishEvent(ctx, "timer.started", entry)
    return entry, nil
}

// StopTimer — останавливает таймер и считает duration
func (s *TimerService) StopTimer(ctx context.Context, tenantID, userID, entryID uuid.UUID) (*model.TimeEntry, error) {
    entry, err := s.repo.FindByID(ctx, tenantID, entryID)
    if err != nil {
        return nil, errors.New("entry not found")
    }
    if entry.UserID != userID {
        return nil, errors.New("forbidden")
    }
    if entry.StoppedAt != nil {
        return nil, errors.New("already stopped")
    }

    now := time.Now().UTC()
    dur := int64(now.Sub(entry.StartedAt).Seconds())
    entry.StoppedAt = &now
    entry.Duration  = &dur

    if err := s.repo.Update(ctx, entry); err != nil {
        return nil, err
    }

    s.publishEvent(ctx, "timer.stopped", entry)
    return entry, nil
}

// GetReport — суммарный отчёт по проекту/дате
func (s *TimerService) GetReport(ctx context.Context, tenantID uuid.UUID, filter ReportFilter) (*Report, error) {
    entries, err := s.repo.FindByFilter(ctx, tenantID, filter)
    if err != nil {
        return nil, err
    }

    report := &Report{
        TotalSeconds: 0,
        ByProject:    make(map[string]int64),
        ByUser:       make(map[string]int64),
    }

    for _, e := range entries {
        if e.Duration != nil {
            report.TotalSeconds += *e.Duration
            report.ByProject[e.ProjectID.String()] += *e.Duration
            report.ByUser[e.UserID.String()] += *e.Duration
        }
    }

    return report, nil
}
```

---

## CRM Service: модели и логика

```go
// services/crm/internal/model/crm.go

type Contact struct {
    TenantBase
    FirstName   string     `gorm:"not null" json:"first_name"`
    LastName    string     `json:"last_name"`
    Email       string     `gorm:"uniqueIndex:idx_tenant_email" json:"email"`
    Phone       string     `json:"phone"`
    CompanyID   *uuid.UUID `gorm:"type:uuid" json:"company_id,omitempty"`
    Tags        []Tag      `gorm:"many2many:contact_tags" json:"tags,omitempty"`
    Deals       []Deal     `gorm:"foreignKey:ContactID" json:"deals,omitempty"`
    TotalTime   int64      `json:"-" gorm:"-"` // из timer-service
}

type Deal struct {
    TenantBase
    Title       string      `gorm:"not null" json:"title"`
    ContactID   uuid.UUID   `gorm:"type:uuid;not null" json:"contact_id"`
    Stage       DealStage   `gorm:"not null" json:"stage"`
    Value       float64     `json:"value"`
    Currency    string      `gorm:"default:'USD'" json:"currency"`
    Probability int         `gorm:"default:0" json:"probability"`
    CloseDate   *time.Time  `json:"close_date,omitempty"`
    AssignedTo  uuid.UUID   `gorm:"type:uuid" json:"assigned_to"`
    Notes       string      `json:"notes"`
    Activities  []Activity  `gorm:"foreignKey:DealID" json:"activities,omitempty"`
}

type DealStage string
const (
    StageNew        DealStage = "new"
    StageContact    DealStage = "contacted"
    StageQualified  DealStage = "qualified"
    StageProposal   DealStage = "proposal"
    StageNegotiation DealStage = "negotiation"
    StageWon        DealStage = "won"
    StageLost       DealStage = "lost"
)

type Activity struct {
    TenantBase
    DealID      uuid.UUID    `gorm:"type:uuid" json:"deal_id"`
    ContactID   uuid.UUID    `gorm:"type:uuid" json:"contact_id"`
    Type        ActivityType `json:"type"`
    Subject     string       `json:"subject"`
    Notes       string       `json:"notes"`
    DueAt       *time.Time   `json:"due_at,omitempty"`
    CompletedAt *time.Time   `json:"completed_at,omitempty"`
    CreatedBy   uuid.UUID    `gorm:"type:uuid" json:"created_by"`
}

type ActivityType string
const (
    ActivityCall     ActivityType = "call"
    ActivityEmail    ActivityType = "email"
    ActivityMeeting  ActivityType = "meeting"
    ActivityTask     ActivityType = "task"
    ActivityNote     ActivityType = "note"
)
```

---

## Shared Database подключение

```go
// shared/database/postgres.go
package database

import (
    "fmt"
    "log"
    "gorm.io/driver/postgres"
    "gorm.io/gorm"
    "gorm.io/gorm/logger"
)

func Connect(dsn string) *gorm.DB {
    db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{
        Logger: logger.Default.LogMode(logger.Info),
    })
    if err != nil {
        log.Fatalf("failed to connect to database: %v", err)
    }

    sqlDB, _ := db.DB()
    sqlDB.SetMaxIdleConns(10)
    sqlDB.SetMaxOpenConns(100)

    return db
}

func ConnectRedis(addr string) *redis.Client {
    rdb := redis.NewClient(&redis.Options{
        Addr: addr,
        DB:   0,
    })
    if err := rdb.Ping(context.Background()).Err(); err != nil {
        log.Fatalf("failed to connect to redis: %v", err)
    }
    return rdb
}
```

---

## Makefile (удобные команды)

```makefile
.PHONY: run-all test lint swagger migrate

run-all:
	@echo "Starting all services..."
	go run services/auth/cmd/main.go &
	go run services/timer/cmd/main.go &
	go run services/video/cmd/main.go &
	go run services/crm/cmd/main.go &
	go run services/billing/cmd/main.go &
	go run services/analytics/cmd/main.go &
	go run services/admin/cmd/main.go &

test:
	go test ./... -v -race -coverprofile=coverage.out
	go tool cover -html=coverage.out -o coverage.html

lint:
	golangci-lint run ./...

swagger:
	swag init -g cmd/main.go --output docs/

migrate-up:
	migrate -path migrations/ -database "$(DATABASE_URL)" up

migrate-down:
	migrate -path migrations/ -database "$(DATABASE_URL)" down 1

build:
	@for svc in auth timer video crm billing analytics admin notification; do \
		go build -o bin/$$svc services/$$svc/cmd/main.go; \
	done
```
