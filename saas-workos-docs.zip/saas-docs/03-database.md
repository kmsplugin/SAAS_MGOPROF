# 03 — База данных: PostgreSQL + Redis + ClickHouse

## Стратегия мультитенантности в БД

Используем **Schema-per-tenant** подход:
- Общая схема `public` — системные таблицы (tenants, plans, billing)
- Схема `tenant_{uuid}` — данные каждой организации

```sql
-- Преимущества:
-- ✅ Полная изоляция данных
-- ✅ Простой backup/restore одного тенанта
-- ✅ Row-level security из коробки
-- ✅ Независимые миграции

-- В GORM меняем схему динамически:
db.Exec("SET search_path TO tenant_" + tenantID)
```

---

## PostgreSQL: Схема `public` (системные таблицы)

```sql
-- Расширения
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Планы подписок
CREATE TABLE plans (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(50) NOT NULL UNIQUE, -- free, starter, pro, enterprise
    price_usd   DECIMAL(10,2) NOT NULL,
    stripe_price_id VARCHAR(100),
    limits      JSONB NOT NULL DEFAULT '{
        "users": 3,
        "projects": 5,
        "storage_gb": 1,
        "video_minutes_month": 60
    }',
    features    JSONB NOT NULL DEFAULT '[]',
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO plans (name, price_usd, limits, features) VALUES
('free',       0,     '{"users":3,"projects":5,"storage_gb":1,"video_minutes_month":60}',    '["timer","crm_basic"]'),
('starter',    19,    '{"users":10,"projects":20,"storage_gb":10,"video_minutes_month":600}', '["timer","crm","video","api"]'),
('pro',        49,    '{"users":50,"projects":100,"storage_gb":50,"video_minutes_month":3000}','["timer","crm","video","api","analytics","admin"]'),
('enterprise', 199,   '{"users":999,"projects":999,"storage_gb":500,"video_minutes_month":999999}','["all","sso","audit","sla"]');

-- Тенанты (организации)
CREATE TABLE tenants (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug            VARCHAR(100) UNIQUE NOT NULL, -- my-company.workos.app
    name            VARCHAR(200) NOT NULL,
    plan_id         UUID REFERENCES plans(id),
    stripe_customer_id  VARCHAR(100),
    stripe_sub_id       VARCHAR(100),
    sub_status      VARCHAR(50) DEFAULT 'trialing', -- trialing, active, past_due, canceled
    trial_ends_at   TIMESTAMPTZ,
    schema_name     VARCHAR(100) NOT NULL, -- tenant_{uuid}
    settings        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Пользователи (глобальные, привязка к тенантам через tenant_users)
CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email           VARCHAR(255) UNIQUE NOT NULL,
    password_hash   VARCHAR(255),
    full_name       VARCHAR(200),
    avatar_url      VARCHAR(500),
    oauth_provider  VARCHAR(50),  -- google, github
    oauth_id        VARCHAR(200),
    is_verified     BOOLEAN DEFAULT FALSE,
    last_login_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Привязка пользователей к тенантам с ролями
CREATE TABLE tenant_users (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id   UUID REFERENCES tenants(id) ON DELETE CASCADE,
    user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
    role        VARCHAR(50) NOT NULL DEFAULT 'member', -- owner, admin, manager, member, viewer
    is_active   BOOLEAN DEFAULT TRUE,
    invited_by  UUID REFERENCES users(id),
    joined_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, user_id)
);

-- Refresh tokens
CREATE TABLE refresh_tokens (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
    tenant_id   UUID REFERENCES tenants(id) ON DELETE CASCADE,
    token_hash  VARCHAR(255) UNIQUE NOT NULL,
    expires_at  TIMESTAMPTZ NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_refresh_tokens_hash ON refresh_tokens(token_hash);
CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);
```

---

## PostgreSQL: Схема `tenant_{id}` (данные тенанта)

```sql
-- Эта миграция запускается при создании нового тенанта

-- Проекты
CREATE TABLE projects (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(200) NOT NULL,
    description TEXT,
    color       VARCHAR(7) DEFAULT '#6366f1',
    client_id   UUID,
    is_archived BOOLEAN DEFAULT FALSE,
    created_by  UUID NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Записи времени
CREATE TABLE time_entries (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id  UUID REFERENCES projects(id) ON DELETE SET NULL,
    user_id     UUID NOT NULL,
    description TEXT,
    started_at  TIMESTAMPTZ NOT NULL,
    stopped_at  TIMESTAMPTZ,
    duration    INTEGER, -- секунды, NULL если запущен
    is_billable BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_time_entries_user       ON time_entries(user_id);
CREATE INDEX idx_time_entries_project    ON time_entries(project_id);
CREATE INDEX idx_time_entries_started_at ON time_entries(started_at DESC);

-- Контакты CRM
CREATE TABLE contacts (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name  VARCHAR(100) NOT NULL,
    last_name   VARCHAR(100),
    email       VARCHAR(255),
    phone       VARCHAR(50),
    company     VARCHAR(200),
    position    VARCHAR(200),
    source      VARCHAR(100), -- web, referral, cold_outreach...
    notes       TEXT,
    custom_fields JSONB DEFAULT '{}',
    created_by  UUID NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Сделки CRM
CREATE TABLE deals (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title       VARCHAR(300) NOT NULL,
    contact_id  UUID REFERENCES contacts(id) ON DELETE SET NULL,
    stage       VARCHAR(50) NOT NULL DEFAULT 'new',
    value       DECIMAL(15,2),
    currency    VARCHAR(3) DEFAULT 'USD',
    probability INTEGER DEFAULT 0,
    close_date  DATE,
    assigned_to UUID NOT NULL,
    notes       TEXT,
    created_by  UUID NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_deals_stage       ON deals(stage);
CREATE INDEX idx_deals_assigned_to ON deals(assigned_to);

-- Активности CRM
CREATE TABLE activities (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    deal_id         UUID REFERENCES deals(id) ON DELETE CASCADE,
    contact_id      UUID REFERENCES contacts(id) ON DELETE CASCADE,
    type            VARCHAR(50) NOT NULL, -- call, email, meeting, task, note
    subject         VARCHAR(300),
    notes           TEXT,
    due_at          TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    created_by      UUID NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Видеокомнаты
CREATE TABLE video_rooms (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    livekit_room_id VARCHAR(200) UNIQUE NOT NULL,
    name            VARCHAR(200) NOT NULL,
    created_by      UUID NOT NULL,
    started_at      TIMESTAMPTZ DEFAULT NOW(),
    ended_at        TIMESTAMPTZ,
    recording_url   VARCHAR(500),
    participant_count INTEGER DEFAULT 0,
    duration_seconds  INTEGER,
    deal_id         UUID REFERENCES deals(id) ON DELETE SET NULL,
    contact_id      UUID REFERENCES contacts(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Участники видеозвонков
CREATE TABLE video_participants (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id     UUID REFERENCES video_rooms(id) ON DELETE CASCADE,
    user_id     UUID NOT NULL,
    joined_at   TIMESTAMPTZ NOT NULL,
    left_at     TIMESTAMPTZ,
    duration    INTEGER -- секунды
);
```

---

## Redis: структуры данных

```
# Активные таймеры (для real-time UI)
timer:active:{tenant_id}:{user_id}
  TYPE: Hash
  FIELDS: entry_id, project_id, started_at, description
  TTL: 24 часа

# Сессии пользователей
session:{tenant_id}:{user_id}
  TYPE: String (JSON)
  TTL: 24 часа

# Rate limiting (по тенанту)
ratelimit:{tenant_id}:{endpoint}
  TYPE: String (counter)
  TTL: 60 секунд

# Pub/Sub каналы для real-time
timer.started    → клиент обновляет UI
timer.stopped    → клиент обновляет UI
deal.updated     → CRM обновляет воронку
video.room.event → обновление участников

# Кэш отчётов (дорогие запросы)
report:{tenant_id}:{hash_of_params}
  TYPE: String (JSON)
  TTL: 5 минут
```

---

## ClickHouse: аналитические события

```sql
-- Подключаемся к ClickHouse для аналитики

-- Основная таблица событий
CREATE TABLE events (
    event_id      UUID DEFAULT generateUUIDv4(),
    tenant_id     UUID NOT NULL,
    user_id       UUID NOT NULL,
    event_type    String NOT NULL,  -- timer.started, deal.won, video.joined...
    entity_type   String,           -- project, deal, room...
    entity_id     UUID,
    properties    String,           -- JSON
    created_at    DateTime64(3) DEFAULT now()
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(created_at)
ORDER BY (tenant_id, created_at, event_type);

-- Агрегат: время по проектам (обновляется каждый час)
CREATE MATERIALIZED VIEW project_time_daily
ENGINE = SummingMergeTree()
ORDER BY (tenant_id, project_id, date)
AS SELECT
    tenant_id,
    JSONExtractString(properties, 'project_id') AS project_id,
    toDate(created_at) AS date,
    sum(JSONExtractInt(properties, 'duration')) AS total_seconds
FROM events
WHERE event_type = 'timer.stopped'
GROUP BY tenant_id, project_id, date;

-- Агрегат: воронка CRM
CREATE MATERIALIZED VIEW deal_funnel_daily
ENGINE = SummingMergeTree()
ORDER BY (tenant_id, stage, date)
AS SELECT
    tenant_id,
    JSONExtractString(properties, 'stage') AS stage,
    toDate(created_at) AS date,
    count() AS count,
    sum(JSONExtractFloat(properties, 'value')) AS total_value
FROM events
WHERE event_type IN ('deal.created', 'deal.stage_changed', 'deal.won', 'deal.lost')
GROUP BY tenant_id, stage, date;
```

---

## Миграции (golang-migrate)

```
migrations/
├── public/
│   ├── 000001_create_plans.up.sql
│   ├── 000001_create_plans.down.sql
│   ├── 000002_create_tenants.up.sql
│   ├── 000002_create_tenants.down.sql
│   └── 000003_create_users.up.sql
└── tenant/
    ├── 000001_create_projects.up.sql
    ├── 000002_create_time_entries.up.sql
    ├── 000003_create_crm.up.sql
    └── 000004_create_video.up.sql
```

```go
// Запуск миграций при создании тенанта
func RunTenantMigrations(db *sql.DB, tenantID string) error {
    schemaName := "tenant_" + tenantID
    db.Exec("CREATE SCHEMA IF NOT EXISTS " + schemaName)
    db.Exec("SET search_path TO " + schemaName)

    m, err := migrate.New("file://migrations/tenant", dsn)
    if err != nil {
        return err
    }
    return m.Up()
}
```
