# 04 — Frontend: Next.js 14 + TypeScript

## Стек фронтенда

| Технология | Роль |
|-----------|------|
| Next.js 14 (App Router) | Фреймворк |
| TypeScript 5 | Типизация |
| Tailwind CSS | Стили |
| shadcn/ui | UI-компоненты |
| Zustand | Стейт-менеджмент |
| TanStack Query | Серверный стейт / кэш |
| TanStack Table | Таблицы |
| Recharts | Графики и дашборды |
| React Hook Form + Zod | Формы + валидация |
| LiveKit React SDK | Видеоконференции |
| next-auth | Аутентификация |
| nuqs | URL state (фильтры) |

---

## Структура проекта

```
frontend/
├── app/
│   ├── (auth)/
│   │   ├── login/page.tsx
│   │   ├── register/page.tsx
│   │   └── layout.tsx
│   ├── (dashboard)/
│   │   ├── layout.tsx          # Sidebar + Header
│   │   ├── page.tsx            # Dashboard overview
│   │   ├── timer/
│   │   │   ├── page.tsx        # Timer главная
│   │   │   ├── projects/       # Управление проектами
│   │   │   └── reports/        # Отчёты
│   │   ├── video/
│   │   │   ├── page.tsx        # Список комнат
│   │   │   └── [roomId]/       # Комната конференции
│   │   ├── crm/
│   │   │   ├── contacts/
│   │   │   ├── deals/
│   │   │   └── activities/
│   │   ├── analytics/
│   │   └── settings/
│   ├── admin/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── tenants/
│   │   └── users/
│   ├── api/
│   │   └── auth/[...nextauth]/
│   ├── layout.tsx
│   └── globals.css
├── components/
│   ├── timer/
│   │   ├── TimerWidget.tsx     # Главный виджет таймера
│   │   ├── ActiveTimer.tsx     # Текущий активный таймер
│   │   ├── TimeEntryList.tsx   # История записей
│   │   └── ProjectPicker.tsx   # Выбор проекта
│   ├── video/
│   │   ├── VideoRoom.tsx       # LiveKit комната
│   │   ├── ParticipantTile.tsx # Плитка участника
│   │   └── ControlBar.tsx      # Кнопки микрофон/камера
│   ├── crm/
│   │   ├── DealPipeline.tsx    # Kanban-доска сделок
│   │   ├── ContactCard.tsx     # Карточка контакта
│   │   └── ActivityFeed.tsx    # Лента активностей
│   ├── analytics/
│   │   ├── TimeChart.tsx       # График времени
│   │   ├── DealFunnel.tsx      # Воронка продаж
│   │   └── StatsCards.tsx      # Карточки KPI
│   └── ui/                     # shadcn/ui компоненты
├── hooks/
│   ├── useTimer.ts             # Логика таймера + WebSocket
│   ├── useTenant.ts            # Текущий тенант
│   └── usePermissions.ts       # RBAC на фронте
├── lib/
│   ├── api.ts                  # API клиент
│   ├── auth.ts                 # next-auth config
│   └── utils.ts
├── stores/
│   ├── timerStore.ts           # Zustand таймер
│   └── uiStore.ts              # UI стейт
└── types/
    └── index.ts                # Все TypeScript типы
```

---

## API клиент (типизированный)

```typescript
// lib/api.ts
import { getSession } from 'next-auth/react';

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8080';

async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const session = await getSession();

  const res = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${session?.accessToken}`,
      'X-Tenant-ID': session?.tenantId || '',
      ...options.headers,
    },
  });

  if (!res.ok) {
    const error = await res.json();
    throw new Error(error.message || 'Request failed');
  }

  return res.json();
}

// Timer API
export const timerApi = {
  start: (projectId: string, description: string) =>
    request('/api/v1/timer/start', {
      method: 'POST',
      body: JSON.stringify({ project_id: projectId, description }),
    }),

  stop: () =>
    request('/api/v1/timer/stop', { method: 'POST' }),

  getActive: () =>
    request<TimeEntry | null>('/api/v1/timer/active'),

  getEntries: (params: ReportFilter) =>
    request<TimeEntry[]>('/api/v1/timer/entries?' + new URLSearchParams(params as any)),

  getReport: (params: ReportFilter) =>
    request<Report>('/api/v1/timer/report?' + new URLSearchParams(params as any)),
};

// CRM API
export const crmApi = {
  getContacts: (q?: string) =>
    request<Contact[]>(`/api/v1/crm/contacts${q ? `?q=${q}` : ''}`),

  createContact: (data: CreateContactInput) =>
    request<Contact>('/api/v1/crm/contacts', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getDeals: (stage?: string) =>
    request<Deal[]>(`/api/v1/crm/deals${stage ? `?stage=${stage}` : ''}`),

  updateDealStage: (id: string, stage: string) =>
    request<Deal>(`/api/v1/crm/deals/${id}/stage`, {
      method: 'PATCH',
      body: JSON.stringify({ stage }),
    }),
};

// Video API
export const videoApi = {
  createRoom: (name: string) =>
    request<VideoRoom>('/api/v1/video/rooms', {
      method: 'POST',
      body: JSON.stringify({ name }),
    }),

  joinRoom: (roomId: string) =>
    request<{ token: string }>(`/api/v1/video/rooms/${roomId}/token`),

  getRooms: () =>
    request<VideoRoom[]>('/api/v1/video/rooms'),
};
```

---

## TimerWidget компонент

```typescript
// components/timer/TimerWidget.tsx
'use client';

import { useState, useEffect } from 'react';
import { useTimerStore } from '@/stores/timerStore';
import { timerApi } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { ProjectPicker } from './ProjectPicker';
import { Play, Square, Timer } from 'lucide-react';
import { formatDuration } from '@/lib/utils';

export function TimerWidget() {
  const { active, setActive, clearActive } = useTimerStore();
  const [elapsed, setElapsed] = useState(0);
  const [description, setDescription] = useState('');
  const [projectId, setProjectId] = useState<string>('');
  const [loading, setLoading] = useState(false);

  // Считаем elapsed каждую секунду
  useEffect(() => {
    if (!active) return;
    const started = new Date(active.started_at).getTime();
    const tick = setInterval(() => {
      setElapsed(Math.floor((Date.now() - started) / 1000));
    }, 1000);
    return () => clearInterval(tick);
  }, [active]);

  const handleStart = async () => {
    if (!projectId) return;
    setLoading(true);
    try {
      const entry = await timerApi.start(projectId, description);
      setActive(entry);
      setElapsed(0);
    } finally {
      setLoading(false);
    }
  };

  const handleStop = async () => {
    setLoading(true);
    try {
      await timerApi.stop();
      clearActive();
      setElapsed(0);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center gap-3 bg-card border rounded-xl px-4 py-3 shadow-sm">
      <Timer className="text-primary h-5 w-5 shrink-0" />

      <input
        value={description}
        onChange={e => setDescription(e.target.value)}
        placeholder="Над чем работаешь?"
        className="flex-1 bg-transparent outline-none text-sm placeholder:text-muted-foreground"
        disabled={!!active}
      />

      <ProjectPicker
        value={projectId}
        onChange={setProjectId}
        disabled={!!active}
      />

      {active && (
        <span className="font-mono text-lg font-semibold text-primary min-w-[80px] text-right">
          {formatDuration(elapsed)}
        </span>
      )}

      {active ? (
        <Button
          size="icon"
          variant="destructive"
          onClick={handleStop}
          disabled={loading}
        >
          <Square className="h-4 w-4" />
        </Button>
      ) : (
        <Button
          size="icon"
          onClick={handleStart}
          disabled={loading || !projectId}
        >
          <Play className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}
```

---

## DealPipeline (Kanban CRM)

```typescript
// components/crm/DealPipeline.tsx
'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { crmApi } from '@/lib/api';
import { DealCard } from './DealCard';

const STAGES = [
  { id: 'new',         label: 'Новые',       color: 'bg-slate-100' },
  { id: 'contacted',   label: 'Контакт',     color: 'bg-blue-50' },
  { id: 'qualified',   label: 'Квалифиц.',   color: 'bg-violet-50' },
  { id: 'proposal',    label: 'Предложение', color: 'bg-amber-50' },
  { id: 'negotiation', label: 'Переговоры',  color: 'bg-orange-50' },
  { id: 'won',         label: 'Выиграно',    color: 'bg-green-50' },
  { id: 'lost',        label: 'Проиграно',   color: 'bg-red-50' },
];

export function DealPipeline() {
  const qc = useQueryClient();
  const { data: deals = [] } = useQuery({
    queryKey: ['deals'],
    queryFn: () => crmApi.getDeals(),
  });

  const moveDeal = useMutation({
    mutationFn: ({ id, stage }: { id: string; stage: string }) =>
      crmApi.updateDealStage(id, stage),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['deals'] }),
  });

  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {STAGES.map(stage => {
        const stageDeals = deals.filter(d => d.stage === stage.id);
        const totalValue = stageDeals.reduce((sum, d) => sum + (d.value || 0), 0);

        return (
          <div key={stage.id} className={`flex-shrink-0 w-72 rounded-xl ${stage.color} p-3`}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-sm">{stage.label}</h3>
              <div className="text-xs text-muted-foreground">
                {stageDeals.length} · ${totalValue.toLocaleString()}
              </div>
            </div>

            <div className="space-y-2">
              {stageDeals.map(deal => (
                <DealCard
                  key={deal.id}
                  deal={deal}
                  onMove={(newStage) => moveDeal.mutate({ id: deal.id, stage: newStage })}
                />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
```

---

## Video Room (LiveKit)

```typescript
// components/video/VideoRoom.tsx
'use client';

import {
  LiveKitRoom,
  VideoConference,
  RoomAudioRenderer,
  ControlBar,
} from '@livekit/components-react';
import '@livekit/components-styles';
import { useEffect, useState } from 'react';
import { videoApi } from '@/lib/api';

interface VideoRoomProps {
  roomId: string;
}

export function VideoRoom({ roomId }: VideoRoomProps) {
  const [token, setToken] = useState<string>('');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    videoApi.joinRoom(roomId)
      .then(res => setToken(res.token))
      .catch(() => setError('Не удалось подключиться к комнате'));
  }, [roomId]);

  if (error) return <div className="text-red-500">{error}</div>;
  if (!token) return <div>Подключение...</div>;

  return (
    <LiveKitRoom
      token={token}
      serverUrl={process.env.NEXT_PUBLIC_LIVEKIT_URL}
      connect={true}
      video={true}
      audio={true}
      className="h-full"
    >
      <VideoConference />
      <RoomAudioRenderer />
      <ControlBar />
    </LiveKitRoom>
  );
}
```

---

## Zustand: Timer Store

```typescript
// stores/timerStore.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface TimerStore {
  active: TimeEntry | null;
  setActive: (entry: TimeEntry) => void;
  clearActive: () => void;
}

export const useTimerStore = create<TimerStore>()(
  persist(
    (set) => ({
      active: null,
      setActive: (entry) => set({ active: entry }),
      clearActive: () => set({ active: null }),
    }),
    { name: 'timer-store' }
  )
);
```

---

## Utility функции

```typescript
// lib/utils.ts
export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

export function formatCurrency(amount: number, currency = 'USD'): string {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency,
  }).format(amount);
}
```
