# 05 — REST API + OpenAPI 3.0 (Swagger)

## Принципы API

- Все эндпойнты: `/api/v1/...`
- Аутентификация: `Authorization: Bearer {jwt}`
- Мультитенант: автоматически из JWT-токена
- Пагинация: `?page=1&limit=20`
- Формат ошибок: `{ "error": "message", "code": "ERROR_CODE" }`
- Версионирование: через URL (`/v1/`, `/v2/`)

---

## Auth Service (`/api/v1/auth`)

```
POST   /auth/register          Регистрация нового пользователя + тенанта
POST   /auth/login             Логин (email + password)
POST   /auth/logout            Разлогин (инвалидация refresh token)
POST   /auth/refresh           Обновление access token
GET    /auth/me                Текущий пользователь
POST   /auth/oauth/google      OAuth2 через Google
POST   /auth/invite            Пригласить пользователя в тенант
PUT    /auth/me                Обновить профиль
POST   /auth/password/reset    Запрос сброса пароля
POST   /auth/password/confirm  Подтверждение нового пароля
```

**POST /auth/register**
```json
// Request
{
  "email":        "user@example.com",
  "password":     "SecurePass123!",
  "full_name":    "Иван Петров",
  "company_name": "Моя Компания"  // создаёт новый тенант
}

// Response 201
{
  "access_token":  "eyJhbGc...",
  "refresh_token": "rt_abc123...",
  "expires_in":    3600,
  "user": {
    "id":       "uuid",
    "email":    "user@example.com",
    "full_name":"Иван Петров"
  },
  "tenant": {
    "id":   "uuid",
    "slug": "moya-kompaniya",
    "plan": "trial"
  }
}
```

---

## Timer Service (`/api/v1/timer`)

```
POST   /timer/start            Запустить таймер
POST   /timer/stop             Остановить активный таймер
GET    /timer/active           Текущий активный таймер
GET    /timer/entries          История записей (с фильтрами)
POST   /timer/entries          Создать запись вручную
PUT    /timer/entries/:id      Обновить запись
DELETE /timer/entries/:id      Удалить запись
GET    /timer/report           Отчёт (summary)
GET    /timer/report/export    Экспорт CSV/PDF

GET    /timer/projects         Список проектов
POST   /timer/projects         Создать проект
PUT    /timer/projects/:id     Обновить проект
DELETE /timer/projects/:id     Архивировать проект
```

**GET /timer/entries** (с фильтрами)
```
Query params:
  project_id  UUID     (опционально)
  user_id     UUID     (опционально, только admin/manager)
  from        date     2025-01-01
  to          date     2025-01-31
  billable    bool
  page        int      default: 1
  limit       int      default: 20 max: 100

Response 200:
{
  "data": [
    {
      "id":          "uuid",
      "project":     { "id": "uuid", "name": "Проект A", "color": "#6366f1" },
      "user":        { "id": "uuid", "full_name": "Иван П." },
      "description": "Правка багов",
      "started_at":  "2025-01-15T09:00:00Z",
      "stopped_at":  "2025-01-15T11:30:00Z",
      "duration":    9000,
      "is_billable": true
    }
  ],
  "meta": {
    "total":        143,
    "page":         1,
    "limit":        20,
    "total_seconds": 328500
  }
}
```

**GET /timer/report**
```
Query params:
  from, to, project_id, user_id, group_by (project|user|day|week)

Response 200:
{
  "total_seconds": 432000,
  "total_formatted": "120h 0m",
  "billable_seconds": 396000,
  "by_project": [
    { "project_id": "uuid", "name": "Проект A", "seconds": 180000, "percentage": 41.7 }
  ],
  "by_user": [...],
  "by_day": [
    { "date": "2025-01-01", "seconds": 28800 }
  ]
}
```

---

## CRM Service (`/api/v1/crm`)

```
# Контакты
GET    /crm/contacts           Список контактов (поиск: ?q=)
POST   /crm/contacts           Создать контакт
GET    /crm/contacts/:id       Контакт + история
PUT    /crm/contacts/:id       Обновить контакт
DELETE /crm/contacts/:id       Удалить контакт

# Сделки
GET    /crm/deals              Список сделок (?stage=)
POST   /crm/deals              Создать сделку
GET    /crm/deals/:id          Сделка + активности
PUT    /crm/deals/:id          Обновить сделку
PATCH  /crm/deals/:id/stage    Изменить стадию
DELETE /crm/deals/:id          Удалить сделку

# Активности
GET    /crm/activities         Лента активностей
POST   /crm/activities         Создать активность
PUT    /crm/activities/:id     Обновить
PATCH  /crm/activities/:id/complete  Отметить выполненной

# Аналитика CRM
GET    /crm/funnel             Воронка продаж (по стадиям)
GET    /crm/pipeline-value     Стоимость pipeline
```

**POST /crm/deals**
```json
// Request
{
  "title":       "Редизайн сайта",
  "contact_id":  "uuid",
  "stage":       "proposal",
  "value":       150000,
  "currency":    "RUB",
  "probability": 60,
  "close_date":  "2025-03-31",
  "assigned_to": "uuid",
  "notes":       "Клиент ждёт КП до пятницы"
}

// Response 201
{
  "id":          "uuid",
  "title":       "Редизайн сайта",
  "contact":     { "id": "uuid", "first_name": "Анна", "last_name": "Смирнова" },
  "stage":       "proposal",
  "value":       150000,
  "currency":    "RUB",
  "probability": 60,
  "close_date":  "2025-03-31",
  "assigned_to": { "id": "uuid", "full_name": "Менеджер 1" },
  "created_at":  "2025-01-15T10:00:00Z"
}
```

---

## Video Service (`/api/v1/video`)

```
GET    /video/rooms            Список комнат
POST   /video/rooms            Создать комнату
GET    /video/rooms/:id        Информация о комнате
DELETE /video/rooms/:id        Закрыть комнату
GET    /video/rooms/:id/token  Получить LiveKit токен для входа
GET    /video/rooms/:id/participants  Участники
GET    /video/history          История звонков
```

**GET /video/rooms/:id/token**
```json
// Response 200
{
  "token":       "eyJhbGc...",  // LiveKit JWT token
  "server_url":  "wss://livekit.your-domain.com",
  "room_name":   "Встреча команды",
  "expires_in":  3600
}
```

---

## Billing Service (`/api/v1/billing`)

```
GET    /billing/plans          Доступные планы
GET    /billing/subscription   Текущая подписка тенанта
POST   /billing/subscribe      Подписаться на план
POST   /billing/cancel         Отменить подписку
GET    /billing/invoices        История счетов
POST   /billing/portal         Stripe Customer Portal URL
GET    /billing/usage           Текущее использование (лимиты)
POST   /billing/webhook        Stripe Webhook (внутренний)
```

**GET /billing/usage**
```json
{
  "plan": "starter",
  "period": "2025-01",
  "usage": {
    "users":            { "used": 7, "limit": 10 },
    "projects":         { "used": 12, "limit": 20 },
    "storage_gb":       { "used": 3.2, "limit": 10 },
    "video_minutes":    { "used": 234, "limit": 600 }
  },
  "next_reset_at": "2025-02-01T00:00:00Z"
}
```

---

## Admin Service (`/api/v1/admin`)

```
# Только для SuperAdmin (role=superadmin)
GET    /admin/tenants          Все тенанты
GET    /admin/tenants/:id      Детали тенанта
PATCH  /admin/tenants/:id      Изменить план/лимиты
DELETE /admin/tenants/:id      Деактивировать тенант
GET    /admin/stats            Общая статистика платформы
GET    /admin/users            Все пользователи

# Tenant Admin (role=admin, своя организация)
GET    /admin/org/users        Пользователи организации
POST   /admin/org/users/invite Пригласить пользователя
PATCH  /admin/org/users/:id/role  Изменить роль
DELETE /admin/org/users/:id    Удалить из организации
GET    /admin/org/audit-log    Лог действий в организации
```

---

## OpenAPI 3.0 спецификация (yaml-заголовок)

```yaml
openapi: 3.0.3
info:
  title: WorkOS SaaS API
  description: Timer + Video + CRM unified platform
  version: 1.0.0
  contact:
    email: api@workos.app

servers:
  - url: https://api.workos.app/api/v1
    description: Production
  - url: http://localhost:8080/api/v1
    description: Local development

security:
  - BearerAuth: []

components:
  securitySchemes:
    BearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT

  schemas:
    Error:
      type: object
      properties:
        error:
          type: string
        code:
          type: string

    Pagination:
      type: object
      properties:
        total:  { type: integer }
        page:   { type: integer }
        limit:  { type: integer }
```

---

## Swagger UI (автогенерация через Swaggo)

```go
// В каждом хендлере добавляем Swaggo-аннотации:

// StartTimer godoc
// @Summary     Запустить таймер
// @Description Запускает новый таймер. Если есть активный — останавливает его.
// @Tags        Timer
// @Accept      json
// @Produce     json
// @Security    BearerAuth
// @Param       body body StartTimerRequest true "Параметры запуска"
// @Success     201 {object} TimeEntry
// @Failure     400 {object} Error
// @Failure     401 {object} Error
// @Router      /timer/start [post]
func (h *TimerHandler) StartTimer(c *gin.Context) { ... }
```

```bash
# Генерация swagger docs:
swag init -g cmd/main.go --output docs/

# Доступ: http://localhost:8080/swagger/index.html
```
