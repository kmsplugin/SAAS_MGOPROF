# 06 — Billing: Stripe + Мультитенантность

## Архитектура биллинга

```
Тенант создан
    │
    ▼
Stripe Customer создан (billing-service)
    │
    ▼
Пользователь выбирает план → Stripe Checkout Session
    │
    ├── Успех → Webhook: customer.subscription.created
    │                   → обновляем tenant.plan + tenant.sub_status
    │
    ├── Оплата просрочена → Webhook: invoice.payment_failed
    │                       → уведомление + grace period 3 дня
    │
    └── Отмена → Webhook: customer.subscription.deleted
                 → downgrade на Free plan
```

---

## Go: Billing Service

```go
// services/billing/internal/service/billing_service.go
package service

import (
    "context"
    "fmt"

    "github.com/stripe/stripe-go/v78"
    "github.com/stripe/stripe-go/v78/checkout/session"
    "github.com/stripe/stripe-go/v78/customer"
    "github.com/stripe/stripe-go/v78/portal/session"
    "github.com/stripe/stripe-go/v78/webhook"
)

type BillingService struct {
    repo      *repository.BillingRepository
    tenantRepo *tenantRepository.TenantRepository
    stripe    *stripe.Client
    webhookSecret string
}

// CreateStripeCustomer — вызывается при регистрации нового тенанта
func (s *BillingService) CreateStripeCustomer(ctx context.Context, tenantID, email, name string) (string, error) {
    params := &stripe.CustomerParams{
        Email: stripe.String(email),
        Name:  stripe.String(name),
        Metadata: map[string]string{
            "tenant_id": tenantID,
        },
    }

    c, err := customer.New(params)
    if err != nil {
        return "", fmt.Errorf("stripe customer creation failed: %w", err)
    }

    // Сохраняем stripe_customer_id в tenant
    s.tenantRepo.UpdateStripeCustomer(ctx, tenantID, c.ID)
    return c.ID, nil
}

// CreateCheckoutSession — генерирует ссылку на оплату
func (s *BillingService) CreateCheckoutSession(ctx context.Context, tenantID, planName, successURL, cancelURL string) (string, error) {
    tenant, err := s.tenantRepo.FindByID(ctx, tenantID)
    if err != nil {
        return "", err
    }

    plan, err := s.repo.FindPlanByName(ctx, planName)
    if err != nil {
        return "", err
    }

    params := &stripe.CheckoutSessionParams{
        Customer:           stripe.String(tenant.StripeCustomerID),
        Mode:               stripe.String(string(stripe.CheckoutSessionModeSubscription)),
        SuccessURL:         stripe.String(successURL + "?session_id={CHECKOUT_SESSION_ID}"),
        CancelURL:          stripe.String(cancelURL),
        LineItems: []*stripe.CheckoutSessionLineItemParams{
            {
                Price:    stripe.String(plan.StripePriceID),
                Quantity: stripe.Int64(1),
            },
        },
        SubscriptionData: &stripe.CheckoutSessionSubscriptionDataParams{
            Metadata: map[string]string{
                "tenant_id": tenantID,
            },
        },
        AllowPromotionCodes: stripe.Bool(true),
    }

    sess, err := session.New(params)
    if err != nil {
        return "", err
    }

    return sess.URL, nil
}

// CreatePortalSession — Stripe Customer Portal (управление подпиской)
func (s *BillingService) CreatePortalSession(ctx context.Context, tenantID, returnURL string) (string, error) {
    tenant, _ := s.tenantRepo.FindByID(ctx, tenantID)

    params := &stripePortal.SessionParams{
        Customer:  stripe.String(tenant.StripeCustomerID),
        ReturnURL: stripe.String(returnURL),
    }

    sess, err := stripePortal.New(params)
    if err != nil {
        return "", err
    }

    return sess.URL, nil
}

// HandleWebhook — обрабатывает события от Stripe
func (s *BillingService) HandleWebhook(ctx context.Context, payload []byte, sig string) error {
    event, err := webhook.ConstructEvent(payload, sig, s.webhookSecret)
    if err != nil {
        return fmt.Errorf("webhook signature verification failed: %w", err)
    }

    switch event.Type {

    case "customer.subscription.created", "customer.subscription.updated":
        var sub stripe.Subscription
        if err := json.Unmarshal(event.Data.Raw, &sub); err != nil {
            return err
        }
        tenantID := sub.Metadata["tenant_id"]
        planName := s.getPlanNameByPriceID(ctx, sub.Items.Data[0].Price.ID)

        s.tenantRepo.UpdateSubscription(ctx, tenantID, UpdateSubParams{
            StripeSubID: sub.ID,
            PlanName:    planName,
            Status:      string(sub.Status),
            PeriodEnd:   time.Unix(sub.CurrentPeriodEnd, 0),
        })

        s.notifyService.Send(ctx, tenantID, "subscription.updated", planName)

    case "customer.subscription.deleted":
        var sub stripe.Subscription
        json.Unmarshal(event.Data.Raw, &sub)
        tenantID := sub.Metadata["tenant_id"]

        // Downgrade на Free
        s.tenantRepo.UpdateSubscription(ctx, tenantID, UpdateSubParams{
            PlanName: "free",
            Status:   "canceled",
        })

    case "invoice.payment_failed":
        var inv stripe.Invoice
        json.Unmarshal(event.Data.Raw, &inv)
        tenantID := inv.Subscription.Metadata["tenant_id"]

        s.tenantRepo.UpdateSubStatus(ctx, tenantID, "past_due")
        s.notifyService.SendEmail(ctx, tenantID, "payment_failed")

    case "invoice.payment_succeeded":
        var inv stripe.Invoice
        json.Unmarshal(event.Data.Raw, &inv)
        tenantID := inv.Subscription.Metadata["tenant_id"]

        s.tenantRepo.UpdateSubStatus(ctx, tenantID, "active")
    }

    return nil
}
```

---

## Webhook Handler (HTTP)

```go
// services/billing/internal/handler/webhook_handler.go

// HandleStripeWebhook godoc
// @Summary     Stripe Webhook
// @Tags        Billing
// @Router      /billing/webhook [post]
func (h *BillingHandler) HandleStripeWebhook(c *gin.Context) {
    payload, err := io.ReadAll(c.Request.Body)
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "cannot read body"})
        return
    }

    sig := c.GetHeader("Stripe-Signature")

    if err := h.service.HandleWebhook(c.Request.Context(), payload, sig); err != nil {
        // Важно: всегда отвечаем 200, иначе Stripe будет повторять
        h.logger.Error("webhook error", zap.Error(err))
    }

    c.JSON(http.StatusOK, gin.H{"received": true})
}
```

---

## Планы и лимиты

```go
// shared/models/limits.go

type PlanLimits struct {
    Users              int   `json:"users"`
    Projects           int   `json:"projects"`
    StorageGB          float64 `json:"storage_gb"`
    VideoMinutesMonth  int   `json:"video_minutes_month"`
}

var Plans = map[string]PlanLimits{
    "free": {
        Users: 3, Projects: 5,
        StorageGB: 1, VideoMinutesMonth: 60,
    },
    "starter": {
        Users: 10, Projects: 20,
        StorageGB: 10, VideoMinutesMonth: 600,
    },
    "pro": {
        Users: 50, Projects: 100,
        StorageGB: 50, VideoMinutesMonth: 3000,
    },
    "enterprise": {
        Users: 9999, Projects: 9999,
        StorageGB: 500, VideoMinutesMonth: 999999,
    },
}

// Middleware проверки лимитов
func CheckLimit(limitType string) gin.HandlerFunc {
    return func(c *gin.Context) {
        tenantID := c.GetString("tenant_id")

        // Получаем текущий план и использование из Redis (кэш)
        usage, _ := getUsageFromCache(tenantID)
        plan := getPlanForTenant(tenantID)
        limits := Plans[plan]

        switch limitType {
        case "users":
            if usage.Users >= limits.Users {
                c.AbortWithStatusJSON(http.StatusPaymentRequired, gin.H{
                    "error": "user limit reached",
                    "code":  "LIMIT_EXCEEDED",
                    "limit": limits.Users,
                    "upgrade_url": "/settings/billing",
                })
                return
            }
        case "video_minutes":
            if usage.VideoMinutes >= limits.VideoMinutesMonth {
                c.AbortWithStatusJSON(http.StatusPaymentRequired, gin.H{
                    "error": "video minutes limit reached",
                    "code":  "LIMIT_EXCEEDED",
                })
                return
            }
        }

        c.Next()
    }
}
```

---

## Цены (Stripe Dashboard)

```
Продукт: WorkOS SaaS

Starter ($19/mo):
  - stripe_price_id: price_starter_monthly
  - trial: 14 дней
  - billing: monthly

Pro ($49/mo):
  - stripe_price_id: price_pro_monthly
  - trial: 14 дней
  - billing: monthly

Pro Annual ($39/mo · $468/yr):
  - stripe_price_id: price_pro_annual
  - скидка: 20%

Enterprise ($199/mo):
  - stripe_price_id: price_enterprise_monthly
  - custom invoicing доступен
```

---

## ENV переменные для Stripe

```env
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_STARTER=price_...
STRIPE_PRICE_PRO=price_...
STRIPE_PRICE_ENTERPRISE=price_...
```
