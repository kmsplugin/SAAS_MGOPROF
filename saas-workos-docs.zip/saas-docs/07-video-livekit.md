# 07 — Video Conferencing: LiveKit WebRTC

## Почему LiveKit

- Написан на **Go** (идеально интегрируется с нашим стеком)
- Open Source + Self-hosted (нет зависимости от облака)
- Поддержка до **100+ участников** в комнате
- Запись в S3/MinIO из коробки
- Активно развивается в 2025-2026

---

## Архитектура видеосервиса

```
[Клиент] ←WebRTC→ [LiveKit Server] ←API→ [video-service (Go)]
                         │
                    [MinIO / S3]
                   (записи звонков)
```

---

## Go: Video Service

```go
// services/video/internal/service/video_service.go
package service

import (
    "context"
    "fmt"
    "time"

    lksdk "github.com/livekit/server-sdk-go/v2"
    "github.com/livekit/protocol/auth"
    "github.com/livekit/protocol/livekit"
)

type VideoService struct {
    lkHost     string
    lkAPIKey   string
    lkSecret   string
    roomClient *lksdk.RoomServiceClient
    repo       *repository.VideoRepository
    logger     *zap.Logger
}

func NewVideoService(cfg *config.Config, repo *repository.VideoRepository, logger *zap.Logger) *VideoService {
    roomClient := lksdk.NewRoomServiceClient(cfg.LiveKitHost, cfg.LiveKitAPIKey, cfg.LiveKitSecret)

    return &VideoService{
        lkHost:     cfg.LiveKitHost,
        lkAPIKey:   cfg.LiveKitAPIKey,
        lkSecret:   cfg.LiveKitSecret,
        roomClient: roomClient,
        repo:       repo,
        logger:     logger,
    }
}

// CreateRoom — создаём комнату в LiveKit + сохраняем в БД
func (s *VideoService) CreateRoom(ctx context.Context, tenantID, userID uuid.UUID, name string) (*model.VideoRoom, error) {
    lkRoomID := "room_" + uuid.New().String()

    // Создаём комнату в LiveKit
    _, err := s.roomClient.CreateRoom(ctx, &livekit.CreateRoomRequest{
        Name:            lkRoomID,
        EmptyTimeout:    300,  // Закрыть через 5 мин если пусто
        MaxParticipants: 100,
        Metadata:        fmt.Sprintf(`{"tenant_id":"%s"}`, tenantID),
    })
    if err != nil {
        return nil, fmt.Errorf("livekit room creation failed: %w", err)
    }

    // Сохраняем в PostgreSQL
    room := &model.VideoRoom{
        TenantBase:    models.TenantBase{TenantID: tenantID},
        LiveKitRoomID: lkRoomID,
        Name:          name,
        CreatedBy:     userID,
        StartedAt:     time.Now().UTC(),
    }

    if err := s.repo.Create(ctx, room); err != nil {
        return nil, err
    }

    return room, nil
}

// GenerateToken — генерируем LiveKit JWT для участника
func (s *VideoService) GenerateToken(ctx context.Context, tenantID, userID uuid.UUID, roomID string, isPublisher bool) (string, error) {
    // Проверяем что комната принадлежит тенанту
    room, err := s.repo.FindByLiveKitID(ctx, tenantID, roomID)
    if err != nil || room == nil {
        return "", fmt.Errorf("room not found")
    }

    // Проверяем лимит видео-минут тенанта
    if err := s.checkVideoLimit(ctx, tenantID); err != nil {
        return "", err
    }

    // Получаем данные пользователя
    user, _ := s.userRepo.FindByID(ctx, userID)

    at := auth.NewAccessToken(s.lkAPIKey, s.lkSecret)
    grant := &auth.VideoGrant{
        RoomJoin: true,
        Room:     roomID,
        CanPublish:     &isPublisher,
        CanSubscribe:   boolPtr(true),
        CanPublishData: &isPublisher,
    }

    at.AddGrant(grant).
        SetIdentity(userID.String()).
        SetName(user.FullName).
        SetValidFor(2 * time.Hour)

    return at.ToJWT()
}

// CloseRoom — закрываем комнату и сохраняем статистику
func (s *VideoService) CloseRoom(ctx context.Context, tenantID uuid.UUID, roomID string) error {
    room, err := s.repo.FindByLiveKitID(ctx, tenantID, roomID)
    if err != nil {
        return err
    }

    // Получаем статистику из LiveKit перед закрытием
    lkRoom, _ := s.roomClient.GetParticipants(ctx, &livekit.ListParticipantsRequest{
        Room: roomID,
    })

    // Закрываем в LiveKit
    s.roomClient.DeleteRoom(ctx, &livekit.DeleteRoomRequest{Room: roomID})

    // Обновляем запись в БД
    now := time.Now().UTC()
    dur := int(now.Sub(room.StartedAt).Seconds())
    room.EndedAt          = &now
    room.DurationSeconds  = &dur
    room.ParticipantCount = len(lkRoom.Participants)
    s.repo.Update(ctx, room)

    // Записываем использование видео-минут для биллинга
    s.billingRepo.AddVideoUsage(ctx, tenantID, dur/60)

    return nil
}

// HandleWebhook — события от LiveKit Server
func (s *VideoService) HandleWebhook(ctx context.Context, event *livekit.WebhookEvent) error {
    switch event.Event {
    case "participant_joined":
        s.repo.AddParticipant(ctx, event.Room.Name, event.Participant.Identity)

    case "participant_left":
        s.repo.UpdateParticipantLeft(ctx, event.Room.Name, event.Participant.Identity)

    case "room_finished":
        tenantID := extractTenantFromMeta(event.Room.Metadata)
        s.CloseRoom(ctx, tenantID, event.Room.Name)

    case "egress_ended": // Запись завершена
        if event.EgressInfo != nil {
            s.saveRecordingURL(ctx, event.Room.Name, event.EgressInfo.FileResults)
        }
    }

    return nil
}
```

---

## Запись звонков (S3/MinIO)

```go
// Запустить запись комнаты
func (s *VideoService) StartRecording(ctx context.Context, tenantID uuid.UUID, roomID string) error {
    egressClient := lksdk.NewEgressClient(s.lkHost, s.lkAPIKey, s.lkSecret)

    req := &livekit.RoomCompositeEgressRequest{
        RoomName: roomID,
        Layout:   "speaker-dark",
        Output: &livekit.RoomCompositeEgressRequest_File{
            File: &livekit.EncodedFileOutput{
                FileType: livekit.EncodedFileType_MP4,
                Filepath: fmt.Sprintf("recordings/%s/%s.mp4", tenantID, roomID),
                Output: &livekit.EncodedFileOutput_S3{
                    S3: &livekit.S3Upload{
                        AccessKey: s.s3AccessKey,
                        Secret:    s.s3Secret,
                        Region:    "us-east-1",
                        Bucket:    "workos-recordings",
                        Endpoint:  s.minioEndpoint, // для MinIO
                    },
                },
            },
        },
    }

    _, err := egressClient.StartRoomCompositeEgress(ctx, req)
    return err
}
```

---

## LiveKit Docker Compose конфиг

```yaml
# infrastructure/docker/livekit/livekit.yaml
port: 7880
rtc:
  tcp_port: 7881
  port_range_start: 50000
  port_range_end: 60000
  use_external_ip: true

redis:
  address: redis:6379

room:
  empty_timeout: 300
  max_participants: 100

logging:
  level: info

keys:
  APIKey: ${LIVEKIT_API_KEY}
  APISecret: ${LIVEKIT_API_SECRET}
```

---

## ENV переменные

```env
LIVEKIT_HOST=wss://livekit.your-domain.com
LIVEKIT_API_KEY=APIxxxxxxxx
LIVEKIT_API_SECRET=secret_xxxxxxxx
LIVEKIT_WEBHOOK_SECRET=webhook_secret

MINIO_ENDPOINT=http://minio:9000
MINIO_ACCESS_KEY=minio_key
MINIO_SECRET_KEY=minio_secret
MINIO_BUCKET=workos-recordings
```

---

## Фронтенд: полная страница видеозвонка

```typescript
// app/(dashboard)/video/[roomId]/page.tsx
import { VideoRoom } from '@/components/video/VideoRoom';

export default function VideoRoomPage({ params }: { params: { roomId: string } }) {
  return (
    <div className="h-screen bg-black">
      <VideoRoom roomId={params.roomId} />
    </div>
  );
}
```

```typescript
// Список комнат
// app/(dashboard)/video/page.tsx
'use client';

import { useQuery, useMutation } from '@tanstack/react-query';
import { videoApi } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Video, Plus, Clock, Users } from 'lucide-react';
import Link from 'next/link';

export default function VideoPage() {
  const { data: rooms = [] } = useQuery({
    queryKey: ['video-rooms'],
    queryFn: videoApi.getRooms,
  });

  const createRoom = useMutation({
    mutationFn: () => videoApi.createRoom('Новая встреча'),
    onSuccess: (room) => {
      window.location.href = `/video/${room.id}`;
    },
  });

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Видеоконференции</h1>
        <Button onClick={() => createRoom.mutate()}>
          <Plus className="h-4 w-4 mr-2" />
          Новая встреча
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {rooms.map(room => (
          <Link key={room.id} href={`/video/${room.id}`}>
            <div className="border rounded-xl p-4 hover:border-primary transition-colors cursor-pointer">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-primary/10 p-2 rounded-lg">
                  <Video className="h-5 w-5 text-primary" />
                </div>
                <span className="font-semibold">{room.name}</span>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {room.participant_count}
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {new Date(room.started_at).toLocaleTimeString()}
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
```
