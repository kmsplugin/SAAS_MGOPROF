# 08 — Админ-панель

## Два уровня администрирования

```
SuperAdmin (Anthropic/owner)
    └── Видит ВСЕ тенанты, статусы, биллинг, логи

Tenant Admin (владелец организации)
    └── Видит ТОЛЬКО свою организацию
        ├── Пользователи и роли
        ├── Настройки и интеграции
        ├── Биллинг своей организации
        └── Аудит-лог
```

---

## SuperAdmin: что видит

```typescript
// app/admin/page.tsx — SuperAdmin дашборд

Метрики платформы:
├── Всего тенантов: 1,247
├── Активных (платящих): 892
├── MRR: $43,450
├── Trial: 234
├── Churned за месяц: 12
├── Новых за месяц: 67
└── DAU/MAU: 68%

Таблица тенантов:
├── Имя организации
├── Plan (Free / Starter / Pro / Enterprise)
├── Sub Status (active / trial / past_due / canceled)
├── Пользователей
├── Создан
└── Действия (изменить план, заблокировать, войти)
```

---

## RBAC: Роли и права

```go
// shared/middleware/rbac.go

type Permission string

const (
    PermTimerRead       Permission = "timer:read"
    PermTimerWrite      Permission = "timer:write"
    PermCRMRead         Permission = "crm:read"
    PermCRMWrite        Permission = "crm:write"
    PermCRMDelete       Permission = "crm:delete"
    PermVideoCreate     Permission = "video:create"
    PermVideoJoin       Permission = "video:join"
    PermAdminUsers      Permission = "admin:users"
    PermAdminBilling    Permission = "admin:billing"
    PermAdminSettings   Permission = "admin:settings"
    PermReportsAll      Permission = "reports:all"
    PermReportsSelf     Permission = "reports:self"
)

var RolePermissions = map[string][]Permission{
    "owner": {
        PermTimerRead, PermTimerWrite,
        PermCRMRead, PermCRMWrite, PermCRMDelete,
        PermVideoCreate, PermVideoJoin,
        PermAdminUsers, PermAdminBilling, PermAdminSettings,
        PermReportsAll,
    },
    "admin": {
        PermTimerRead, PermTimerWrite,
        PermCRMRead, PermCRMWrite, PermCRMDelete,
        PermVideoCreate, PermVideoJoin,
        PermAdminUsers, PermAdminSettings,
        PermReportsAll,
    },
    "manager": {
        PermTimerRead, PermTimerWrite,
        PermCRMRead, PermCRMWrite,
        PermVideoCreate, PermVideoJoin,
        PermReportsAll,
    },
    "member": {
        PermTimerRead, PermTimerWrite,
        PermCRMRead,
        PermVideoJoin,
        PermReportsSelf,
    },
    "viewer": {
        PermTimerRead,
        PermCRMRead,
        PermVideoJoin,
        PermReportsSelf,
    },
}

// Middleware проверки разрешения
func RequirePermission(perm Permission) gin.HandlerFunc {
    return func(c *gin.Context) {
        role := c.GetString("user_role")
        perms, ok := RolePermissions[role]
        if !ok {
            c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "unknown role"})
            return
        }

        for _, p := range perms {
            if p == perm {
                c.Next()
                return
            }
        }

        c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
            "error": "insufficient permissions",
            "required": perm,
        })
    }
}
```

---

## Audit Log

```go
// Логируем все важные действия

type AuditLog struct {
    TenantBase
    UserID     uuid.UUID `gorm:"type:uuid" json:"user_id"`
    Action     string    `gorm:"not null" json:"action"` // user.invited, deal.created, plan.upgraded
    EntityType string    `json:"entity_type"`
    EntityID   uuid.UUID `gorm:"type:uuid" json:"entity_id"`
    IPAddress  string    `json:"ip_address"`
    UserAgent  string    `json:"user_agent"`
    Before     *string   `gorm:"type:jsonb" json:"before,omitempty"`
    After      *string   `gorm:"type:jsonb" json:"after,omitempty"`
    CreatedAt  time.Time `json:"created_at"`
}

// Автоматическое логирование через middleware
func AuditMiddleware(action string) gin.HandlerFunc {
    return func(c *gin.Context) {
        c.Next()

        if c.Writer.Status() < 400 {
            go auditService.Log(c.Request.Context(), AuditEntry{
                TenantID:  c.GetString("tenant_id"),
                UserID:    c.GetString("user_id"),
                Action:    action,
                IPAddress: c.ClientIP(),
                UserAgent: c.Request.UserAgent(),
            })
        }
    }
}
```
