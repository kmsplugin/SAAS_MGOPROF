# 09 — DevOps: Docker + Kubernetes + GitHub Actions

## Dockerfile (шаблон для каждого Go-сервиса)

```dockerfile
# Multi-stage build: маленький итоговый образ
FROM golang:1.23-alpine AS builder

WORKDIR /app

# Зависимости кешируются отдельно (быстрее сборка)
COPY go.mod go.sum ./
RUN go mod download

COPY . .

# Собираем бинарник
RUN CGO_ENABLED=0 GOOS=linux go build \
    -ldflags="-w -s -X main.version=$(git describe --tags --always)" \
    -o /app/service ./cmd/main.go

# Финальный образ: только бинарник (< 20MB)
FROM alpine:3.20

RUN apk add --no-cache ca-certificates tzdata

WORKDIR /app
COPY --from=builder /app/service .

EXPOSE 8001
HEALTHCHECK --interval=30s --timeout=3s \
    CMD wget -qO- http://localhost:8001/health || exit 1

USER nobody
ENTRYPOINT ["./service"]
```

---

## docker-compose.yml (локальная разработка)

```yaml
version: '3.9'

services:
  # ===== INFRASTRUCTURE =====
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: workos
      POSTGRES_PASSWORD: workos_secret
      POSTGRES_DB: workos
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U workos"]
      interval: 5s

  redis:
    image: redis:7.2-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

  clickhouse:
    image: clickhouse/clickhouse-server:24
    ports:
      - "8123:8123"
      - "9000:9000"
    volumes:
      - clickhouse_data:/var/lib/clickhouse

  minio:
    image: minio/minio:latest
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: minio_admin
      MINIO_ROOT_PASSWORD: minio_secret
    ports:
      - "9000:9000"
      - "9001:9001"
    volumes:
      - minio_data:/data

  livekit:
    image: livekit/livekit-server:latest
    command: --config /etc/livekit.yaml
    ports:
      - "7880:7880"
      - "7881:7881"
      - "50000-50020:50000-50020/udp"
    volumes:
      - ./infrastructure/docker/livekit/livekit.yaml:/etc/livekit.yaml

  # ===== SERVICES =====
  auth:
    build:
      context: .
      dockerfile: services/auth/Dockerfile
    env_file: services/auth/.env
    ports:
      - "8001:8001"
    depends_on:
      postgres:
        condition: service_healthy

  timer:
    build:
      context: .
      dockerfile: services/timer/Dockerfile
    env_file: services/timer/.env
    ports:
      - "8002:8002"
    depends_on: [postgres, redis]

  video:
    build:
      context: .
      dockerfile: services/video/Dockerfile
    env_file: services/video/.env
    ports:
      - "8003:8003"
    depends_on: [postgres, livekit]

  crm:
    build:
      context: .
      dockerfile: services/crm/Dockerfile
    env_file: services/crm/.env
    ports:
      - "8004:8004"
    depends_on: [postgres, redis]

  billing:
    build:
      context: .
      dockerfile: services/billing/Dockerfile
    env_file: services/billing/.env
    ports:
      - "8005:8005"
    depends_on: [postgres]

  analytics:
    build:
      context: .
      dockerfile: services/analytics/Dockerfile
    env_file: services/analytics/.env
    ports:
      - "8006:8006"
    depends_on: [clickhouse, redis]

  admin:
    build:
      context: .
      dockerfile: services/admin/Dockerfile
    env_file: services/admin/.env
    ports:
      - "8007:8007"
    depends_on: [postgres]

  gateway:
    image: kong:3.6
    environment:
      KONG_DATABASE: "off"
      KONG_DECLARATIVE_CONFIG: /kong/kong.yml
      KONG_PROXY_LISTEN: 0.0.0.0:8080
    volumes:
      - ./gateway/kong.yml:/kong/kong.yml
    ports:
      - "8080:8080"
    depends_on: [auth, timer, video, crm, billing]

  frontend:
    build:
      context: frontend
      dockerfile: Dockerfile
    ports:
      - "3000:3000"
    environment:
      NEXT_PUBLIC_API_URL: http://localhost:8080
      NEXT_PUBLIC_LIVEKIT_URL: ws://localhost:7880
    depends_on: [gateway]

volumes:
  postgres_data:
  redis_data:
  clickhouse_data:
  minio_data:
```

---

## GitHub Actions CI/CD

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    name: Test & Lint
    runs-on: ubuntu-latest

    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
          POSTGRES_DB: workos_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5

      redis:
        image: redis:7.2-alpine
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s

    steps:
      - uses: actions/checkout@v4

      - name: Set up Go
        uses: actions/setup-go@v5
        with:
          go-version: '1.23'
          cache: true

      - name: Download dependencies
        run: go mod download

      - name: Run linter
        uses: golangci/golangci-lint-action@v6
        with:
          version: latest

      - name: Run tests
        run: |
          go test ./... -v -race \
            -coverprofile=coverage.out \
            -covermode=atomic
        env:
          DATABASE_URL: postgres://test:test@localhost:5432/workos_test
          REDIS_URL: redis://localhost:6379

      - name: Upload coverage
        uses: codecov/codecov-action@v4
        with:
          file: ./coverage.out

  build:
    name: Build & Push Docker
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'

    strategy:
      matrix:
        service: [auth, timer, video, crm, billing, analytics, admin, notification]

    steps:
      - uses: actions/checkout@v4

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Login to GitHub Container Registry
        uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Build and push
        uses: docker/build-push-action@v5
        with:
          context: .
          file: services/${{ matrix.service }}/Dockerfile
          push: true
          tags: |
            ghcr.io/${{ github.repository }}/${{ matrix.service }}:latest
            ghcr.io/${{ github.repository }}/${{ matrix.service }}:${{ github.sha }}
          cache-from: type=gha
          cache-to: type=gha,mode=max

  deploy:
    name: Deploy to Production
    needs: build
    runs-on: ubuntu-latest
    environment: production

    steps:
      - uses: actions/checkout@v4

      - name: Set up kubectl
        uses: azure/setup-kubectl@v3

      - name: Configure kubeconfig
        run: echo "${{ secrets.KUBECONFIG }}" | base64 -d > $HOME/.kube/config

      - name: Deploy to Kubernetes
        run: |
          # Обновляем image tag во всех деплоях
          for service in auth timer video crm billing analytics admin notification; do
            kubectl set image deployment/$service \
              $service=ghcr.io/${{ github.repository }}/$service:${{ github.sha }} \
              -n workos
          done

      - name: Wait for rollout
        run: |
          for service in auth timer video crm billing analytics admin; do
            kubectl rollout status deployment/$service -n workos --timeout=300s
          done

      - name: Run smoke tests
        run: |
          curl -f https://api.workos.app/health || exit 1
          echo "✅ Production is healthy"
```

---

## Kubernetes: основные ресурсы

```yaml
# infrastructure/k8s/timer-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: timer
  namespace: workos
spec:
  replicas: 2
  selector:
    matchLabels:
      app: timer
  template:
    metadata:
      labels:
        app: timer
    spec:
      containers:
        - name: timer
          image: ghcr.io/your-org/workos/timer:latest
          ports:
            - containerPort: 8002
          env:
            - name: DATABASE_URL
              valueFrom:
                secretKeyRef:
                  name: workos-secrets
                  key: database-url
            - name: REDIS_URL
              valueFrom:
                secretKeyRef:
                  name: workos-secrets
                  key: redis-url
          resources:
            requests:
              memory: "64Mi"
              cpu: "100m"
            limits:
              memory: "256Mi"
              cpu: "500m"
          livenessProbe:
            httpGet:
              path: /health
              port: 8002
            initialDelaySeconds: 10
            periodSeconds: 30
          readinessProbe:
            httpGet:
              path: /health
              port: 8002
            initialDelaySeconds: 5
            periodSeconds: 10
---
apiVersion: v1
kind: Service
metadata:
  name: timer
  namespace: workos
spec:
  selector:
    app: timer
  ports:
    - port: 8002
      targetPort: 8002
---
# HPA: автомасштабирование
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: timer-hpa
  namespace: workos
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: timer
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
```

---

## Переменные окружения (шаблон .env)

```env
# Общие для всех сервисов
APP_ENV=production
PORT=8002
LOG_LEVEL=info

# База данных
DATABASE_URL=postgres://workos:secret@postgres:5432/workos
REDIS_URL=redis://redis:6379

# JWT
JWT_SECRET=your_jwt_secret_min_32_chars
JWT_ACCESS_TTL=1h
JWT_REFRESH_TTL=30d

# Сервис-специфичные
LIVEKIT_HOST=wss://livekit.workos.app
LIVEKIT_API_KEY=APIxxxxxxxx
LIVEKIT_API_SECRET=secret_xxx

STRIPE_SECRET_KEY=sk_live_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx

RESEND_API_KEY=re_xxx
FROM_EMAIL=hello@workos.app
```
