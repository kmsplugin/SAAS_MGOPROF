# 10 — Дорожная карта: MVP → V1 → V2

## Принцип: Shipping > Perfection

Задача — выпустить рабочий MVP за 3–4 недели,
затем итеративно доращивать продукт вместе с Claude Code.

---

## 🔴 MVP (Недели 1–4): Ядро работает

### Неделя 1: Фундамент
```
✅ Монорепозиторий настроен (Go + Next.js)
✅ docker-compose с PostgreSQL, Redis, ClickHouse, LiveKit
✅ auth-service: регистрация, логин, JWT, мультитенант
✅ Базовые миграции: public schema (tenants, users, plans)
✅ Базовый API Gateway (Kong)
✅ CI/CD: GitHub Actions (lint + test + build)
```

### Неделя 2: Timer
```
✅ timer-service: проекты, запуск/стоп таймера
✅ WebSocket: real-time обновление активного таймера
✅ Базовые отчёты (по дням, проектам)
✅ Frontend: TimerWidget + список записей
✅ Frontend: Страница проектов
```

### Неделя 3: CRM
```
✅ crm-service: контакты + сделки + активности
✅ Frontend: DealPipeline (Kanban)
✅ Frontend: Список контактов + карточка контакта
✅ Связь Timer ↔ CRM (время на клиента)
```

### Неделя 4: Video + Billing + Admin
```
✅ video-service: комнаты LiveKit + токены
✅ Frontend: VideoRoom + список комнат
✅ billing-service: Stripe планы + Checkout + Webhook
✅ Лимиты по плану (users, video minutes)
✅ Базовая Admin-панель (tenant admin)
✅ Деплой на VPS / Kubernetes
```

**MVP готов к первым пользователям** 🎉

---

## 🟡 V1 (Недели 5–10): Продукт зрелеет

### Неделя 5–6: Качество и UX
```
○ Onboarding flow (wizard для новых тенантов)
○ Email-уведомления (приглашения, напоминания)
○ Экспорт отчётов Timer в PDF и CSV
○ Мобильная адаптация фронтенда
○ Error tracking (Sentry)
○ Логи (Grafana Loki)
○ Метрики (Prometheus + Grafana)
```

### Неделя 7–8: Расширенная аналитика
```
○ analytics-service: события в ClickHouse
○ Dashboard: Productivity score
○ Dashboard: Revenue pipeline (CRM воронка)
○ Dashboard: Team time report
○ Кастомные отчёты с фильтрами
○ Export дашборда в PDF
```

### Неделя 9–10: Интеграции и API
```
○ Public API (для внешних интеграций)
○ Webhooks исходящие (deal.won → ваш webhook)
○ Интеграция с Google Calendar (встречи → активности)
○ Zapier / Make коннектор
○ SSO / SAML (для Enterprise)
○ API Keys management (в настройках)
```

---

## 🟢 V2 (Месяцы 3–6): Рост и масштаб

### Блок A: Мобильное приложение
```
○ React Native (iOS + Android)
○ Офлайн-режим для Timer
○ Push-уведомления
○ Сканер визиток → Контакт в CRM
```

### Блок B: ИИ-функции
```
○ AI-ассистент в CRM (следующий шаг по сделке)
○ Автоматическое описание задач по активности
○ Прогнозирование закрытия сделок (ML)
○ Summary звонка из записи видео (Whisper → GPT)
○ Smart отчёты: аномалии, инсайты
```

### Блок C: Enterprise
```
○ SAML SSO (Okta, Azure AD)
○ Audit Log (compliance)
○ Data residency (EU/US)
○ SLA 99.9% + dedicated support
○ Custom договоры и invoicing
○ Advanced RBAC (кастомные роли)
```

### Блок D: Маркетплейс интеграций
```
○ Slack: уведомления + команды
○ Jira/Linear: синхронизация задач
○ HubSpot: двусторонняя CRM-синхронизация
○ QuickBooks/Xero: экспорт счетов
○ Notion: шаблоны отчётов
```

---

## Workflow с Claude Code (как работать)

### Типичная сессия добавления фичи

```bash
# 1. Ты создаёшь Issue в GitHub
"Feature: добавить теги к time entries"

# 2. Даёшь Claude Code промпт:
"В services/timer добавь поддержку тегов для TimeEntry.
Нужно:
- Модель Tag (GORM, мультитенант)
- many2many связь TimeEntry ↔ Tag
- Миграция
- CRUD эндпойнты /timer/tags
- Фильтрация entries по тегам
- Unit тесты для service и handler
Стиль кода — как в существующих файлах."

# 3. Claude Code:
- Создаёт файлы
- Пишет тесты
- Делает PR в GitHub

# 4. Ты:
- Проверяешь PR
- CI прогоняет тесты
- Мержишь
```

### Промпты для доработки существующего кода

```
"Перепиши timer report endpoint чтобы он кэшировал
результат в Redis на 5 минут. Ключ: report:{tenant_id}:{hash}.
Не трогай бизнес-логику, только добавь кэш-слой."

"Добавь rate limiting в gateway: 100 req/min per tenant,
1000 req/min для Enterprise. Используй Redis sliding window."

"Найди N+1 запросы в crm-service и исправь через
Preload/Joins в GORM. Добавь тест который ловит N+1."
```

---

## Чеклист перед прод-релизом

```
БЕЗОПАСНОСТЬ:
□ Все секреты в environment variables (не в коде)
□ SQL injection невозможен (только GORM / параметры)
□ JWT secret длиной 64+ символа
□ HTTPS везде (Let's Encrypt)
□ Stripe webhook signature проверяется
□ Rate limiting на API Gateway
□ CORS настроен только на нужные домены

НАДЁЖНОСТЬ:
□ Health checks для всех сервисов
□ Graceful shutdown (timeout 30s)
□ Database connection pool настроен
□ Redis failover (Sentinel или Cluster)
□ Kubernetes liveness + readiness probes
□ HPA настроен

МОНИТОРИНГ:
□ Prometheus метрики на /metrics
□ Grafana дашборды (RED: Rate, Errors, Duration)
□ Sentry для error tracking
□ Алёрты: error rate > 1%, latency p99 > 500ms
□ Uptime мониторинг (Betterstack / Uptime Robot)

БИЛЛИНГ:
□ Stripe webhook получает все нужные события
□ Лимиты проверяются перед каждым действием
□ Trial корректно заканчивается
□ Downgrade не ломает существующие данные

ДАННЫЕ:
□ Backup PostgreSQL каждые 6 часов
□ Backup тестируется (restore проверен)
□ Миграции обратно совместимы
□ Soft-delete везде (не физическое удаление)
```

---

## Стоимость инфраструктуры (ориентир)

| Стадия | Инфра | Стоимость/мес |
|--------|-------|--------------|
| MVP (до 50 тенантов) | 1 VPS 4vCPU/8GB | ~$30–50 |
| V1 (до 500 тенантов) | K8s 3 ноды + managed PostgreSQL | ~$200–400 |
| V2 (1000+ тенантов) | K8s multi-AZ + RDS + CloudFront | ~$800–2000 |
